const name = {
    low: "offisito",
    up: "Offisito",
    caps: "OFFISITO",
};

export default name;
