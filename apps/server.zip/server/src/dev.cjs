require('esbuild-register');
require('./index.ts');
